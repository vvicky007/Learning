var express = require('express') ;
var app = express() ;
var bookrouter = express.Router();
bookrouter.route('/').get(
    (req,res) => {
        res.send("Hello");
    }
);
bookrouter.route('/single').get(
    (req,res) => {
        res.send("single");
    }
);

/* if you need routes for different books then instead of single use /:id
id = req.params.id
*/
module.exports = bookrouter