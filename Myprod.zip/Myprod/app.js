var express = require('express') ;
var app = express() ;
// var debug = require('debug')('app');
var chalk = require('chalk');
var morgan = require('morgan');
var path = require('path');
var bookrouter = require('./src/routes/bookroutes');
/*This is used to maintain routes we can use app.get but it's just better way  */


app.use(morgan('tiny'));
/* 
morgan is used to know what's going on with web requests 
combined gives a lot of information where as tiny gives the information you need most 
*/
app.use(express.static(path.join(__dirname,'public')));
/* static tells express that it's static files are there in this folder*/
app.use('/css', express.static(path.join(__dirname,'node_modules/bootstrap/dist/css')));
app.use('/js', express.static(path.join(__dirname,'node_modules/bootstrap/dist/js')));
app.use('/js', express.static(path.join(__dirname,'node_modules/jquery/dist')));

/* setting template Engine first we should have a folder where our dynmaic pages are stored*/
app.set('views' , './src/views');
app.set('view engine', 'ejs');


app.use('/books' , bookrouter);
app.get('/', (req,res) => {
    res.render('index',
    {nav:[{title: "Partner With us" , link: "/books"},
           {title: "about" , link:"/authors"}  ]}) ;
});

app.listen(3000,()=>{
    console.log(`listening on port ${chalk.green(3000)}`);
});