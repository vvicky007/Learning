$(document).ready(function(){

	
	
	 $("#dialog").dialog(
        {
            autoOpen: false,
            modal: false,
            
            buttons: {
                "Close": function () {
                    $("#dialog").dialog("close");
                    
                }
            },
            width: "600px",
            dialogClass: "no-close"

        }
     );
 
  

  $("#form").submit(function (event) {
     alert("yes");
  	     
        if(verifyinput()){
        	$("#dialog").dialog("open");
       
        }
        else{
        	$("#dialog2").dialog();
        }
    
    });
    function verifyinput(){
      var name = $("#name").val() ;
	  var email = $("#email").val();
	  var mob = $("#mob").val();

        if(name.length ==0 || email.length == 0 || mob.length == 0){
            
            return false;
        }
        else{
            return true;
        }
        
        
    }
    




}); 